import { useState } from "react";
import "./index.css";

function App() {
  const [page, setPage] = useState("Home");

  const pages = {
    Home: (
      <>
        <section className="hero">
          <h2>Build a Stronger You</h2>
          <p>Simple fitness tips, workouts and healthy lifestyle ideas.</p>
          <button>Get Started</button>
        </section>

        <section>
          <h2>Why FitLife?</h2>
          <div className="cards">
            <div><h3>🏋️ Workouts</h3><p>Simple exercises for everyone.</p></div>
            <div><h3>🥗 Nutrition</h3><p>Learn healthy eating habits.</p></div>
            <div><h3>💪 Motivation</h3><p>Stay active and motivated.</p></div>
          </div>
        </section>
      </>
    ),

    About: (
      <section className="page">
        <h2>About Us</h2>
        <p>
          FitLife helps people live healthier and more active lives
          through simple fitness tips, workouts and nutrition advice.
        </p>
        <h3>Our Mission</h3>
        <p>To make fitness simple, enjoyable and accessible to everyone.</p>
      </section>
    ),

    Services: (
      <section className="page">
        <h2>Our Services</h2>
        <div className="cards">
          <div><h3>Personal Training</h3><p>Personalized fitness plans.</p></div>
          <div><h3>Workout Plans</h3><p>Beginner-friendly exercises.</p></div>
          <div><h3>Nutrition</h3><p>Healthy eating guidance.</p></div>
        </div>
      </section>
    ),

    Blog: (
      <section className="page">
        <h2>Latest Blogs</h2>
        <div className="cards">
          <div><h3>5 Beginner Exercises</h3><p>Easy exercises to start your journey.</p><button>Read More</button></div>
          <div><h3>Healthy Eating</h3><p>Simple habits for better nutrition.</p><button>Read More</button></div>
          <div><h3>Benefits of Exercise</h3><p>Why regular exercise matters.</p><button>Read More</button></div>
        </div>
      </section>
    ),

    Contact: (
      <section className="page">
        <h2>Contact Us</h2>
        <p>Have a question? Send us a message.</p>
        <form>
          <input placeholder="Your Name" />
          <input type="email" placeholder="Your Email" />
          <textarea placeholder="Your Message" />
          <button>Send Message</button>
        </form>
      </section>
    )
  };

  return (
    <>
      <header>
        <h1>Fit<span>Life</span></h1>
        <nav>
          {Object.keys(pages).map(item => (
            <button key={item} onClick={() => setPage(item)}>
              {item}
            </button>
          ))}
        </nav>
      </header>

      <main>{pages[page]}</main>

      <footer>
        <h3>FitLife</h3>
        <p>© 2026 FitLife. All rights reserved.</p>
      </footer>
    </>
  );
}

export default App;
